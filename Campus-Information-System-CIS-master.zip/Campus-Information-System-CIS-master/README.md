# Campus-Information-System-CIS

## Installation Guide

## First Step:

Copy Repositry

## Second Step:

Import app/data into database

## Requirement:
Visual Studio 2010
MySql Server and Management Studio

## Demo Link

https://rahul-sabhajit.github.io/Campus-Information-System-CIS/

